# coding : latin1
''''
    Trabalho Interdiciplinar: Interação Homem Computador - Linguagem de Programação - Probabilidade e Estatística Aplicada 1


  Integrantes: Adilson Felipe Filho
  Carlos Eduardo Lorenzentti Júnior
  Tiago Samuel Sousa dos Santos
  Vinicius Matheus Martins
  Vitor Parada

'''
import numpy as np
import pandas as pd
from functools import reduce
import math

df = pd.read_csv('DespesasOrgao.csv')
df = df.fillna(0)
x = np.array(df['ValorEmp'])
y = np.array(df['ValorPag'])

x_quad = list(map(lambda z: z * z,x))
y_quad = list(map(lambda z: z * z,y))
xy = list(map(lambda k,j: k * j, x,y))
media_x = reduce(lambda k,j: (k + j), x) / len(x)
media_y = reduce(lambda k,j: (k + j), y) / len(y)
media_x_quad = reduce(lambda k,j: (k + j), x_quad) / len(x_quad)
media_y_quad = reduce(lambda k,j: (k + j), y_quad) / len(y_quad)
media_xy = reduce(lambda k,j: (k + j) , xy) / len (x_quad)

print("\nMédia de X: {:.4f}".format(media_x))
print("Média de Y: {:.4f}".format(media_y))
print("Média de X²: {:.4f}".format(media_x_quad))
print("Média de Y²: {:.4f}".format(media_y_quad))
print("Média de XY: {:.4f}".format(media_xy))
print("Valor de A: {:.4f}".format((media_xy - media_x * media_y) / (media_x_quad - media_x ** 2)))

print("Valor de B: {:.4f}".format(media_y - (media_xy - media_x * media_y) / (media_x_quad - media_x ** 2) * media_x))

print("Regressão Linear: Y = %fx + %f"%(((media_xy - media_x * media_y) / (media_x_quad - media_x ** 2)),
                (media_y - (media_xy - media_x * media_y) / (media_x_quad - media_x ** 2) * media_x)))

print("Medida de Correlação de Pearson: {:.4f}".format((media_xy - media_x * media_y) /
      math.sqrt((media_x_quad - media_x ** 2) * (media_y_quad - media_y ** 2) )))

print("\n========= Correlação de Pearson Detalhada: =========\n")
print(df.corr(method='pearson',min_periods=1))